package casino;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author VALE
 */
public class MaquinaTraga extends javax.swing.JPanel{

   private int monedas = 50;
    public MaquinaTraga() {
        initComponents();
        monedasLabel.setText("Monedas: " + monedas);
    }

    private class RollThread extends Thread {
        private final int numFrames = 20; 
        private final int delay = 50; // tiempo de espera entre cuadros en milisegundos
        private final Icon[] diceIcons; 

        public RollThread() {
            diceIcons = new Icon[] {
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/bar.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/campana.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/cereza.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/corazon.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/diamante.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/herramienta.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/limon.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/siete.png.jpg"))    
            };
        }

        @Override
        public void run() {
            
            for (int i = 0; i < numFrames; i++) {
                int joker1 = (int)(Math.random() * 8);
                int joker2 = (int)(Math.random() * 8);
                int joker3 = (int)(Math.random() * 8);

                // actualiza las imágenes de los dados
                Label.setIcon(diceIcons[joker1]);
                Label2.setIcon(diceIcons[joker2]);
                Label3.setIcon(diceIcons[joker3]);

                // espera un tiempo antes de mostrar el siguiente cuadro
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }

            // muestra el resultado final
            int joker1 = (int)(Math.random() * 8) + 1;
            int joker2 = (int)(Math.random() * 8) + 1;
            int joker3 = (int)(Math.random() * 8) + 1;
            //int resultado = dado1 + dado2;

            // actualiza las imágenes de los dados con los valores reales
            Label.setIcon(diceIcons[joker1 - 1]);
            Label2.setIcon(diceIcons[joker2 - 1]);
            Label3.setIcon(diceIcons[joker3 - 1]);

            if (joker1 == joker2 && joker2 == joker3) {
                JOptionPane.showMessageDialog(null, "¡GANASTE! ¡TODO POR CINCO! ");

                if (monedas < 0) {
                    monedas += Math.abs(monedas); 
                } else {
                    monedas *= 5; 
                }
            } else if (joker1 == joker2 || joker1 == joker3 || joker2 == joker3) {
                JOptionPane.showMessageDialog(null, "ESTUVISTE CERCA... +15 ");
                monedas += 15; // Suma 15 monedas en caso de estar cerca
            } else {
                JOptionPane.showMessageDialog(null, "MÁS SUERTE A LA PROXIMA ... -25 ");
                monedas -= 25; // Resta 25 monedas en caso de perder
            }

            
            monedasLabel.setText("Monedas: " + monedas);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        Label = new javax.swing.JLabel();
        Label2 = new javax.swing.JLabel();
        Label3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        SlotMachine = new javax.swing.JButton();
        monedasLabel = new javax.swing.JLabel();

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/diamante.png.jpg"))); // NOI18N
        Label.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));

        Label2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/diamante.png.jpg"))); // NOI18N
        Label2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        Label3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/diamante.png.jpg"))); // NOI18N
        Label3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel1.setBackground(new java.awt.Color(255, 150, 12));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 0));
        jLabel1.setText("TRAGAMONEDAS");

        SlotMachine.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tragamoney/boton.jpg"))); // NOI18N
        SlotMachine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SlotMachineActionPerformed(evt);
            }
        });

        monedasLabel.setFont(new java.awt.Font("SWRomnd", 1, 14)); // NOI18N
        monedasLabel.setForeground(new java.awt.Color(255, 255, 255));
        monedasLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 51)));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Label, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(Label2, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Label3, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(SlotMachine, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(monedasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(80, 80, 80))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Label3)
                    .addComponent(Label2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Label, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SlotMachine, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(monedasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void SlotMachineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SlotMachineActionPerformed

        RollThread rollThread = new RollThread();
        rollThread.start();
    }//GEN-LAST:event_SlotMachineActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label;
    private javax.swing.JLabel Label2;
    private javax.swing.JLabel Label3;
    private javax.swing.JButton SlotMachine;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel monedasLabel;
    // End of variables declaration//GEN-END:variables

   
    
}
