
package casino;

import javax.swing.Icon;

/**
 *
 * @author VALE
 */
public class TiraDados extends javax.swing.JPanel {

    
    public TiraDados() {
        initComponents();
    }

    private class RollThread extends Thread {
        private final int numFrames = 20; 
        private final int delay = 50; // tiempo de espera entre cuadros en milisegundos
        private final Icon[] diceIcons; 

        public RollThread() {
            diceIcons = new Icon[] {
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados1.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados2.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados3.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados4.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados5.png.jpg")),
                new javax.swing.ImageIcon(getClass().getResource("/Dados/dados6.png.jpg"))
            };
        }

        @Override
        public void run() {
            
            for (int i = 0; i < numFrames; i++) {
                int dado1 = (int)(Math.random() * 6);
                int dado2 = (int)(Math.random() * 6);

                // actualiza las imágenes de los dados
                diceLabel1.setIcon(diceIcons[dado1]);
                diceLabel2.setIcon(diceIcons[dado2]);

                // espera un tiempo antes de mostrar el siguiente cuadro
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }

            // muestra el resultado final
            int dado1 = (int)(Math.random() * 6) + 1;
            int dado2 = (int)(Math.random() * 6) + 1;
            int resultado = dado1 + dado2;

            // actualiza las imágenes de los dados con los valores reales
            diceLabel1.setIcon(diceIcons[dado1 - 1]);
            diceLabel2.setIcon(diceIcons[dado2 - 1]);

            // muestra el resultado final en la etiqueta
            resultLabel.setText("Obtuviste: " + resultado);
        }
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        diceLabel1 = new javax.swing.JLabel();
        diceLabel2 = new javax.swing.JLabel();
        rollButton = new javax.swing.JButton();
        resultLabel = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 0, 0));

        diceLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Dados/dados3.png.jpg"))); // NOI18N

        diceLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Dados/dados2.png.jpg"))); // NOI18N

        rollButton.setFont(new java.awt.Font("PMingLiU-ExtB", 1, 24)); // NOI18N
        rollButton.setText("TIRA LOS DADOS");
        rollButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rollButtonActionPerformed(evt);
            }
        });

        resultLabel.setBackground(new java.awt.Color(255, 204, 102));
        resultLabel.setFont(new java.awt.Font("SWComp", 1, 24)); // NOI18N
        resultLabel.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(rollButton))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(resultLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(diceLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(diceLabel2)))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(rollButton)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(diceLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(diceLabel2))
                .addGap(36, 36, 36)
                .addComponent(resultLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void rollButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rollButtonActionPerformed

        RollThread rollThread = new RollThread();
        rollThread.start();
    }//GEN-LAST:event_rollButtonActionPerformed

                  
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel diceLabel1;
    private javax.swing.JLabel diceLabel2;
    private javax.swing.JLabel resultLabel;
    private javax.swing.JButton rollButton;
    // End of variables declaration//GEN-END:variables
}
