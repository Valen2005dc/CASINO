
package casino;

import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author VALE
 */
public class Casino extends Thread{

    
    }
    
    
    
  

